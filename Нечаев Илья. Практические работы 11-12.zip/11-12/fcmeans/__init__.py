"""fuzzy-c-means - A simple implementation of Fuzzy C-means algorithm."""
from .main import FCM


__version__ = "1.2.1"
